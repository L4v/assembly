#ifndef COMMON_H
#define COMMON_H

void error(char *str);
void print_help(char *fname);

#endif